// Global variables
let currentItinerary = null;
let savedTrips = [];

try {
    const storedTrips = localStorage.getItem('savedTrips');
    if (storedTrips) {
        savedTrips = JSON.parse(storedTrips);
    }
} catch (error) {
    console.error('Error loading saved trips from localStorage:', error);
    savedTrips = [];
}

// Currency conversion rate (1 USD = 83 INR)
const USD_TO_INR = 83;

// Location data for Indian destinations
const destinationLocations = {
    'delhi': [
        'Red Fort',
        'India Gate',
        'Qutub Minar',
        'Lotus Temple',
        'Akshardham Temple',
        'Chandni Chowk',
        'Humayun\'s Tomb',
        'ALL'
    ],
    'agra': [
        'Taj Mahal',
        'Agra Fort',
        'Fatehpur Sikri',
        'Itmad-ud-Daula',
        'Mehtab Bagh',
        'Kinari Bazaar',
        'Jama Masjid',
        'ALL'
    ],
    'andhra pradesh': [
        'Tirupati Temple',
        'Vijayawada',
        'Visakhapatnam',
        'Amaravati',
        'Araku Valley',
        'Lepakshi',
        'Srisailam',
        'ALL'
    ],
    'arunachal pradesh': [
        'Tawang Monastery',
        'Bomdila',
        'Ziro Valley',
        'Namdapha National Park',
        'Sela Pass',
        'Itanagar',
        'Pakhui Wildlife Sanctuary',
        'ALL'
    ],
    'assam': [
        'Kaziranga National Park',
        'Guwahati',
        'Majuli Island',
        'Manas National Park',
        'Sivasagar',
        'Tezpur',
        'Dibrugarh',
        'ALL'
    ],
    'bihar': [
        'Bodh Gaya',
        'Nalanda',
        'Patna',
        'Rajgir',
        'Vaishali',
        'Gaya',
        'Muzaffarpur',
        'ALL'
    ],
    'chhattisgarh': [
        'Raipur',
        'Bilaspur',
        'Jagdalpur',
        'Chitrakoot Falls',
        'Barnawapara Wildlife Sanctuary',
        'Sirpur',
        'Durg',
        'ALL'
    ],
    'goa': [
        'Calangute Beach',
        'Baga Beach',
        'Anjuna Beach',
        'Fort Aguada',
        'Basilica of Bom Jesus',
        'Dudhsagar Falls',
        'Arambol Beach',
        'ALL'
    ],
    'gujarat': [
        'Ahmedabad',
        'Surat',
        'Vadodara',
        'Rajkot',
        'Dwarka',
        'Somnath Temple',
        'Gir National Park',
        'ALL'
    ],
    'haryana': [
        'Gurgaon',
        'Faridabad',
        'Panipat',
        'Ambala',
        'Karnal',
        'Hisar',
        'Rohtak',
        'ALL'
    ],
    'himachal pradesh': [
        'Shimla',
        'Manali',
        'Dharamshala',
        'Kullu',
        'Chamba',
        'Dalhousie',
        'Kangra',
        'ALL'
    ],
    'jammu kashmir': [
        'Srinagar',
        'Gulmarg',
        'Pahalgam',
        'Sonmarg',
        'Dal Lake',
        'Shalimar Bagh',
        'Vaishno Devi',
        'ALL'
    ],
    'jharkhand': [
        'Ranchi',
        'Jamshedpur',
        'Dhanbad',
        'Bokaro',
        'Deoghar',
        'Hazaribagh',
        'Giridih',
        'ALL'
    ],
    'karnataka': [
        'Bangalore',
        'Mysore',
        'Coorg',
        'Hampi',
        'Gokarna',
        'Udupi',
        'Chikmagalur',
        'ALL'
    ],
    'kerala': [
        'Alleppey Backwaters',
        'Munnar Tea Gardens',
        'Periyar Wildlife Sanctuary',
        'Kovalam Beach',
        'Fort Kochi',
        'Wayanad Wildlife',
        'Athirappilly Falls',
        'ALL'
    ],
    'madhya pradesh': [
        'Bhopal',
        'Indore',
        'Jabalpur',
        'Gwalior',
        'Ujjain',
        'Khajuraho',
        'Pachmarhi',
        'ALL'
    ],
    'maharashtra': [
        'Mumbai',
        'Pune',
        'Nagpur',
        'Nashik',
        'Aurangabad',
        'Lonavala',
        'Mahabaleshwar',
        'ALL'
    ],
    'manipur': [
        'Imphal',
        'Loktak Lake',
        'Kangla Fort',
        'Keibul Lamjao National Park',
        'Shri Govindajee Temple',
        'Moirang',
        'Ukhrul',
        'ALL'
    ],
    'meghalaya': [
        'Shillong',
        'Cherrapunjee',
        'Mawlynnong',
        'Dawki',
        'Nongpoh',
        'Jowai',
        'Baghmara',
        'ALL'
    ],
    'mizoram': [
        'Aizawl',
        'Lunglei',
        'Champhai',
        'Serchhip',
        'Kolasib',
        'Lawngtlai',
        'Saiha',
        'ALL'
    ],
    'nagaland': [
        'Kohima',
        'Dimapur',
        'Mokokchung',
        'Tuensang',
        'Wokha',
        'Zunheboto',
        'Phek',
        'ALL'
    ],
    'odisha': [
        'Bhubaneswar',
        'Puri',
        'Konark',
        'Cuttack',
        'Rourkela',
        'Sambalpur',
        'Berhampur',
        'ALL'
    ],
    'punjab': [
        'Amritsar',
        'Ludhiana',
        'Jalandhar',
        'Patiala',
        'Bathinda',
        'Mohali',
        'Pathankot',
        'ALL'
    ],
    'rajasthan': [
        'Jaipur',
        'Udaipur',
        'Jodhpur',
        'Jaisalmer',
        'Pushkar',
        'Ajmer',
        'Bikaner',
        'ALL'
    ],
    'sikkim': [
        'Gangtok',
        'Pelling',
        'Lachung',
        'Yumthang Valley',
        'Rumtek Monastery',
        'Tsomgo Lake',
        'Ravangla',
        'ALL'
    ],
    'tamil nadu': [
        'Chennai',
        'Madurai',
        'Coimbatore',
        'Ooty',
        'Kanyakumari',
        'Rameswaram',
        'Thanjavur',
        'ALL'
    ],
    'telangana': [
        'Hyderabad',
        'Warangal',
        'Nizamabad',
        'Karimnagar',
        'Ramagundam',
        'Khammam',
        'Mahbubnagar',
        'ALL'
    ],
    'tripura': [
        'Agartala',
        'Udaipur',
        'Dharmanagar',
        'Kailashahar',
        'Belonia',
        'Ambassa',
        'Khowai',
        'ALL'
    ],
    'uttar pradesh': [
        'Lucknow',
        'Kanpur',
        'Agra',
        'Varanasi',
        'Allahabad',
        'Meerut',
        'Ghaziabad',
        'ALL'
    ],
    'uttarakhand': [
        'Dehradun',
        'Haridwar',
        'Rishikesh',
        'Nainital',
        'Mussoorie',
        'Almora',
        'Kedarnath',
        'ALL'
    ],
    'west bengal': [
        'Kolkata',
        'Darjeeling',
        'Santiniketan',
        'Murshidabad',
        'Siliguri',
        'Asansol',
        'Howrah',
        'ALL'
    ]
};

// Sample travel packages
const travelPackages = [
    {
        name: 'Budget Explorer Package',
        priceUSD: 800,
        includes: 'Hotel accommodation, local transport, basic meals, guided tours',
        description: 'Perfect for budget-conscious travelers seeking authentic experiences'
    },
    {
        name: 'Comfort Plus Package',
        priceUSD: 1500,
        includes: '3-star hotel, airport transfers, breakfast, city tours, travel insurance',
        description: 'Comfortable stay with all essential services included'
    },
    {
        name: 'Luxury Experience Package',
        priceUSD: 3000,
        includes: '5-star hotel, private transfers, all meals, premium tours, spa sessions, VIP access',
        description: 'Indulge in luxury with premium services and exclusive experiences'
    },
    {
        name: 'Adventure Seeker Package',
        priceUSD: 2000,
        includes: 'Adventure activities, outdoor gear, expert guides, safety equipment, adventure insurance',
        description: 'For thrill-seekers wanting to explore the outdoors'
    }
];

// DOM elements
const homepage = document.getElementById('homepage');
const planningForm = document.getElementById('planning-form');
const itinerarySection = document.getElementById('itinerary');
const savedTripsSection = document.getElementById('saved-trips');
const destinationsSection = document.getElementById('destinations');
const gallerySection = document.getElementById('gallery');
const tripForm = document.getElementById('trip-form');
const generateBtn = document.getElementById('generate-btn');
const saveItineraryBtn = document.getElementById('save-itinerary');
const loading = document.getElementById('loading');
const itineraryContent = document.getElementById('itinerary-content');
const itineraryDays = document.getElementById('itinerary-days');
const weatherInfo = document.getElementById('weather-info');
const tripsList = document.getElementById('trips-list');
const themeToggle = document.getElementById('theme-toggle');
const destinationInput = document.getElementById('destination');
const locationsSelect = document.getElementById('locations');
const packagesList = document.getElementById('packages-list');
const quickTripsList = document.getElementById('quick-trips-list');

// Sample itinerary data based on travel type
const itineraryTemplates = {
    adventure: [
        { day: 1, activities: ['Arrival and check-in', 'Explore local market', 'Hiking trail'] },
        { day: 2, activities: ['Mountain biking', 'Visit waterfall', 'Camping setup'] },
        { day: 3, activities: ['Rock climbing', 'Local cuisine tasting', 'Departure'] }
    ],
    relaxation: [
        { day: 1, activities: ['Arrival and spa session', 'Beach walk', 'Sunset viewing'] },
        { day: 2, activities: ['Yoga session', 'Massage therapy', 'Pool time'] },
        { day: 3, activities: ['Meditation retreat', 'Healthy meal', 'Departure'] }
    ],
    honeymoon: [
        { day: 1, activities: ['Romantic dinner', 'Candlelit walk', 'Stargazing'] },
        { day: 2, activities: ['Private picnic', 'Boat ride', 'Spa for two'] },
        { day: 3, activities: ['Sunrise breakfast', 'Photo session', 'Departure'] }
    ],
    solo: [
        { day: 1, activities: ['Arrival and city walk', 'Visit museum', 'Local cafe'] },
        { day: 2, activities: ['Explore parks', 'Street food tour', 'Night market'] },
        { day: 3, activities: ['Hiking or biking', 'Reflection time', 'Departure'] }
    ],
    family: [
        { day: 1, activities: ['Arrival and family check-in', 'Visit zoo/aquarium', 'Family dinner'] },
        { day: 2, activities: ['Theme park visit', 'Picnic in park', 'Movie night'] },
        { day: 3, activities: ['Beach day', 'Ice cream outing', 'Departure'] }
    ],
    friends: [
        { day: 1, activities: ['Arrival and group check-in', 'Explore nightlife', 'Group dinner'] },
        { day: 2, activities: ['Adventure activities', 'Beach party', 'Late night hangout'] },
        { day: 3, activities: ['Shopping spree', 'Farewell party', 'Departure'] }
    ]
};

// Destination-specific itineraries
const destinationItineraries = {
    'andhra pradesh': {
        family: [
            { day: 1, activities: ['Arrival at Tirupati Airport', 'Visit Tirupati Temple for darshan', 'Family dinner at local Andhra restaurant'] },
            { day: 2, activities: ['Drive to Visakhapatnam', 'Relax at RK Beach and enjoy sea breeze', 'Visit INS Kursura Submarine Museum'] },
            { day: 3, activities: ['Explore Araku Valley tribal culture', 'Coffee plantation tour and local cuisine tasting', 'Departure with family memories'] }
        ]
    }
};

// Destination-specific day titles (sub-places for itinerary days)
const destinationDayTitles = {
    'andhra pradesh': ['Tirupati', 'Araku Valley', 'Visakhapatnam'],
    'delhi': ['Red Fort', 'India Gate', 'Qutub Minar'],
    'agra': ['Taj Mahal', 'Agra Fort', 'Fatehpur Sikri'],
    'arunachal pradesh': ['Tawang Monastery', 'Bomdila', 'Ziro Valley'],
    'assam': ['Kaziranga National Park', 'Guwahati', 'Majuli Island'],
    'bihar': ['Bodh Gaya', 'Nalanda', 'Patna'],
    'chhattisgarh': ['Raipur', 'Bilaspur', 'Jagdalpur'],
    'goa': ['Calangute Beach', 'Baga Beach', 'Anjuna Beach'],
    'gujarat': ['Ahmedabad', 'Surat', 'Vadodara'],
    'haryana': ['Gurgaon', 'Faridabad', 'Panipat'],
    'himachal pradesh': ['Shimla', 'Manali', 'Dharamshala'],
    'jammu kashmir': ['Srinagar', 'Gulmarg', 'Pahalgam'],
    'jharkhand': ['Ranchi', 'Jamshedpur', 'Dhanbad'],
    'karnataka': ['Bangalore', 'Mysore', 'Coorg'],
    'kerala': ['Alleppey Backwaters', 'Munnar Tea Gardens', 'Periyar Wildlife Sanctuary'],
    'madhya pradesh': ['Bhopal', 'Indore', 'Jabalpur'],
    'maharashtra': ['Mumbai', 'Pune', 'Nagpur'],
    'manipur': ['Imphal', 'Loktak Lake', 'Kangla Fort'],
    'meghalaya': ['Shillong', 'Cherrapunjee', 'Mawlynnong'],
    'mizoram': ['Aizawl', 'Lunglei', 'Champhai'],
    'nagaland': ['Kohima', 'Dimapur', 'Mokokchung'],
    'odisha': ['Bhubaneswar', 'Puri', 'Konark'],
    'punjab': ['Amritsar', 'Ludhiana', 'Jalandhar'],
    'rajasthan': ['Jaipur', 'Udaipur', 'Jodhpur'],
    'sikkim': ['Gangtok', 'Pelling', 'Lachung'],
    'tamil nadu': ['Chennai', 'Madurai', 'Coimbatore'],
    'telangana': ['Hyderabad', 'Warangal', 'Nizamabad'],
    'tripura': ['Agartala', 'Udaipur', 'Dharmanagar'],
    'uttar pradesh': ['Lucknow', 'Kanpur', 'Agra'],
    'uttarakhand': ['Dehradun', 'Haridwar', 'Rishikesh'],
    'west bengal': ['Kolkata', 'Darjeeling', 'Santiniketan']
};

// Coordinates for destinations (latitude, longitude)
const destinationCoordinates = {
    'delhi': [28.6139, 77.2090],
    'agra': [27.1767, 78.0081],
    'andhra pradesh': [15.9129, 79.7400], // Approximate for Vijayawada
    'jammu kashmir': [34.0837, 74.7973], // Srinagar
    'kerala': [10.8505, 76.2711], // Approximate for Kochi
    'goa': [15.2993, 74.1240],
    'manali': [32.2432, 77.1892]
};

// Coordinates for specific locations (latitude, longitude)
const locationCoordinates = {
    'Red Fort': [28.6562, 77.2410],
    'India Gate': [28.6129, 77.2295],
    'Qutub Minar': [28.5244, 77.1855],
    'Lotus Temple': [28.5535, 77.2588],
    'Akshardham Temple': [28.6183, 77.2773],
    'Chandni Chowk': [28.6562, 77.2300],
    'Humayun\'s Tomb': [28.5933, 77.2507],
    'Taj Mahal': [27.1751, 78.0421],
    'Agra Fort': [27.1795, 78.0211],
    'Fatehpur Sikri': [27.0945, 77.6664],
    'Tirupati Temple': [13.6288, 79.4192],
    'Visakhapatnam': [17.6868, 83.2185],
    'Araku Valley': [18.3333, 82.8667],
    'Srinagar': [34.0837, 74.7973],
    'Gulmarg': [34.0484, 74.3805],
    'Pahalgam': [34.0161, 75.3150],
    'Dal Lake': [34.0837, 74.7973],
    'Shalimar Bagh': [34.0837, 74.7973],
    'Vaishno Devi': [33.0317, 74.9350],
    'Alleppey Backwaters': [9.4981, 76.3388],
    'Munnar Tea Gardens': [10.0889, 77.0595],
    'Periyar Wildlife Sanctuary': [9.4667, 77.2333],
    'Kovalam Beach': [8.4004, 76.9787],
    'Fort Kochi': [9.9658, 76.2424],
    'Wayanad Wildlife': [11.6854, 76.1320],
    'Athirappilly Falls': [10.2867, 76.5700],
    'Calangute Beach': [15.5480, 73.7553],
    'Baga Beach': [15.5557, 73.7510],
    'Anjuna Beach': [15.5833, 73.7333],
    'Fort Aguada': [15.4917, 73.7733],
    'Basilica of Bom Jesus': [15.5009, 73.9116],
    'Dudhsagar Falls': [15.3144, 74.3144],
    'Arambol Beach': [15.6833, 73.7000],
    'Manali': [32.2432, 77.1892]
};

// Weather code to description mapping (Open-Meteo)
const weatherDescriptions = {
    0: 'Clear sky',
    1: 'Mainly clear',
    2: 'Partly cloudy',
    3: 'Overcast',
    45: 'Fog',
    48: 'Depositing rime fog',
    51: 'Light drizzle',
    53: 'Moderate drizzle',
    55: 'Dense drizzle',
    56: 'Light freezing drizzle',
    57: 'Dense freezing drizzle',
    61: 'Slight rain',
    63: 'Moderate rain',
    65: 'Heavy rain',
    66: 'Light freezing rain',
    67: 'Heavy freezing rain',
    71: 'Slight snow fall',
    73: 'Moderate snow fall',
    75: 'Heavy snow fall',
    77: 'Snow grains',
    80: 'Slight rain showers',
    81: 'Moderate rain showers',
    82: 'Heavy rain showers',
    85: 'Slight snow showers',
    86: 'Heavy snow showers',
    95: 'Thunderstorm',
    96: 'Thunderstorm with slight hail',
    99: 'Thunderstorm with heavy hail'
};

// Weather API function (using Open-Meteo - free API, no key required)
async function getWeather(destination) {
    try {
        const coords = destinationCoordinates[destination.toLowerCase()];
        if (!coords) {
            return 'Weather data not available for this destination';
        }

        const [lat, lon] = coords;
        const response = await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current_weather=true`);
        const data = await response.json();

        if (data.current_weather) {
            const temp = Math.round(data.current_weather.temperature);
            const weatherCode = data.current_weather.weathercode;
            const description = weatherDescriptions[weatherCode] || 'Unknown weather';
            return `${description}, ${temp}°C`;
        } else {
            return 'Weather data not available';
        }
    } catch (error) {
        console.error('Error fetching weather:', error);
        return 'Weather data not available';
    }
}

// Navigation functions
function showSection(section) {
    document.querySelectorAll('.section').forEach(sec => sec.classList.remove('active'));
    section.classList.add('active');
}

// Navigation event listeners
document.getElementById('nav-home').addEventListener('click', (e) => {
    e.preventDefault();
    showSection(homepage);
    updateActiveNav('nav-home');
});

document.getElementById('nav-destinations').addEventListener('click', (e) => {
    e.preventDefault();
    if (destinationsSection.classList.contains('active')) return;
    showSection(destinationsSection);
    initializeCarousel();
    updateActiveNav('nav-destinations');
});

document.getElementById('nav-gallery').addEventListener('click', (e) => {
    e.preventDefault();
    showSection(gallerySection);
    updateActiveNav('nav-gallery');
});

document.getElementById('nav-plan').addEventListener('click', (e) => {
    e.preventDefault();
    showSection(planningForm);
    updateActiveNav('nav-plan');
});

document.getElementById('nav-saved').addEventListener('click', (e) => {
    e.preventDefault();
    showSection(savedTripsSection);
    updateActiveNav('nav-saved');
});

// Other event listeners
document.getElementById('start-planning-btn').addEventListener('click', () => {
    showSection(planningForm);
    updateActiveNav('nav-plan');
});

document.getElementById('view-saved-trips-btn').addEventListener('click', () => {
    showSection(savedTripsSection);
    updateActiveNav('nav-saved');
});

document.getElementById('back-to-home').addEventListener('click', () => {
    showSection(homepage);
    updateActiveNav('nav-home');
});

document.getElementById('back-to-form').addEventListener('click', () => {
    showSection(planningForm);
    updateActiveNav('nav-plan');
});

document.getElementById('back-to-home-from-saved').addEventListener('click', () => {
    showSection(homepage);
    updateActiveNav('nav-home');
});

document.getElementById('back-to-home-from-destinations').addEventListener('click', () => {
    showSection(homepage);
    updateActiveNav('nav-home');
});

document.getElementById('back-to-home-from-gallery').addEventListener('click', () => {
    showSection(homepage);
    updateActiveNav('nav-home');
});

// Function to update active navigation link
function updateActiveNav(activeId) {
    document.querySelectorAll('.nav-links a').forEach(link => {
        link.classList.remove('active');
    });
    document.getElementById(activeId).classList.add('active');
}

// Form submission
tripForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const destination = document.getElementById('destination').value;
    const startDate = document.getElementById('start-date').value;
    const endDate = document.getElementById('end-date').value;
    const budget = document.getElementById('budget').value;
    const travelType = document.getElementById('travel-type').value;
    const locationsSelect = document.getElementById('locations');
    const selectedLocations = Array.from(locationsSelect.selectedOptions).map(option => option.value);

    // Calculate number of days
    const start = new Date(startDate);
    const end = new Date(endDate);
    const days = Math.ceil((end - start) / (1000 * 60 * 60 * 24)) + 1;

    currentItinerary = {
        destination,
        startDate,
        endDate,
        budget,
        travelType,
        days,
        locations: selectedLocations
    };
    
    showSection(itinerarySection);
    loading.style.display = 'block';
    itineraryContent.style.display = 'none';
    
    // Simulate loading time
    setTimeout(async () => {
        await generateItinerary();
        loading.style.display = 'none';
        itineraryContent.style.display = 'block';
    }, 2000);
});

// Generate itinerary
async function generateItinerary() {
    // Check for destination-specific itinerary first
    let template = null;
    if (destinationItineraries[currentItinerary.destination.toLowerCase()] &&
        destinationItineraries[currentItinerary.destination.toLowerCase()][currentItinerary.travelType]) {
        template = destinationItineraries[currentItinerary.destination.toLowerCase()][currentItinerary.travelType];
    } else {
        template = itineraryTemplates[currentItinerary.travelType] || itineraryTemplates.adventure;
    }

    // Get weather
    const weather = await getWeather(currentItinerary.destination);
    document.getElementById('weather-text').textContent = weather;

    // Calculate budget per person
    const budgetPerPerson = calculateBudgetPerPerson(currentItinerary.budget, currentItinerary.days);

    // Add budget summary before itinerary days
    const budgetSummary = document.createElement('div');
    budgetSummary.className = 'budget-summary';
    budgetSummary.innerHTML = `
        <div class="budget-card">
            <h3><i class="fas fa-calculator"></i> Trip Budget Summary</h3>
            <div class="budget-details">
                <div class="budget-item">
                    <span>Duration:</span>
                    <span>${currentItinerary.days} days</span>
                </div>
                <div class="budget-item">
                    <span>Budget Range:</span>
                    <span>${currentItinerary.budget.charAt(0).toUpperCase() + currentItinerary.budget.slice(1)}</span>
                </div>
                <div class="budget-item total">
                    <span>Total Cost Per Person:</span>
                    <span>₹${budgetPerPerson.toLocaleString()}</span>
                </div>
            </div>
        </div>
    `;

    // Clear previous content and add budget summary
    itineraryDays.innerHTML = '';
    itineraryDays.appendChild(budgetSummary);

    // Generate days
    for (let i = 0; i < currentItinerary.days && i < template.length; i++) {
        const day = template[i];
        const dayCard = document.createElement('div');
        dayCard.className = 'day-card';

        // Get selected locations or show all if none selected
        const locationsToShow = currentItinerary.locations && currentItinerary.locations.length > 0
            ? currentItinerary.locations.filter(loc => loc !== 'ALL')
            : destinationLocations[currentItinerary.destination.toLowerCase()]?.filter(loc => loc !== 'ALL') || [];

        // Determine day title: Day 1 is destination, subsequent days use destination-specific sub-places if available
        let dayTitle = currentItinerary.destination;
        const destKey = currentItinerary.destination.toLowerCase();
        if (day.day > 1 && destinationDayTitles[destKey] && destinationDayTitles[destKey][day.day - 2]) {
            dayTitle = destinationDayTitles[destKey][day.day - 2]; // Day 2 uses index 0, Day 3 uses index 1, etc.
        } else if (day.day > 1 && locationsToShow.length >= day.day - 1) {
            dayTitle = locationsToShow[day.day - 2]; // Fallback to selected locations
        }

        dayCard.innerHTML = `
            <h3>Day ${day.day}: ${dayTitle}</h3>
            ${locationsToShow.length > 0 ? `
                <div class="selected-locations">
                    <h4><i class="fas fa-map-marker-alt"></i> Selected Locations:</h4>
                    <p>${locationsToShow.join(', ')}</p>
                </div>
            ` : ''}
            ${day.activities.map(activity => `
                <div class="activity">
                    <i class="fas fa-check-circle"></i>
                    <span>${activity}</span>
                </div>
            `).join('')}
        `;
        itineraryDays.appendChild(dayCard);
    }

    // Initialize map with selected locations
    initializeMap();
}

// Save itinerary
saveItineraryBtn.addEventListener('click', () => {
    if (currentItinerary) {
        const tripName = prompt('Enter a name for your trip:');
        if (tripName && tripName.trim()) {
            savedTrips.push({
                ...currentItinerary,
                name: tripName.trim(),
                id: Date.now(),
                savedAt: new Date().toISOString()
            });
            localStorage.setItem('savedTrips', JSON.stringify(savedTrips));
            alert('Itinerary saved successfully!');
            displaySavedTrips();
            // Navigate back to planning form after saving
            showSection(planningForm);
            updateActiveNav('nav-plan');
        } else if (tripName !== null) {
            alert('Please enter a valid trip name.');
        }
    }
});

// Display saved trips
function displaySavedTrips() {
    tripsList.innerHTML = '';
    if (savedTrips.length === 0) {
        tripsList.innerHTML = '<p>No saved trips yet.</p>';
        return;
    }

    savedTrips.forEach(trip => {
        const tripCard = document.createElement('div');
        tripCard.className = 'trip-card';
        tripCard.innerHTML = `
            <div class="trip-info">
                <h3>${trip.name || trip.destination}</h3>
                <p>${trip.startDate} to ${trip.endDate}</p>
                <p>Budget: ${trip.budget} | Type: ${trip.travelType}</p>
            </div>
            <div class="trip-actions">
                <button class="btn primary" onclick="viewTrip(${trip.id})">View</button>
                <button class="btn secondary" onclick="deleteTrip(${trip.id})">Delete</button>
            </div>
        `;
        tripsList.appendChild(tripCard);
    });

    // Update quick access trips
    displayQuickSavedTrips();
}

// View trip details
function viewTrip(id) {
    const trip = savedTrips.find(t => t.id === id);
    if (trip) {
        currentItinerary = trip;
        showSection(itinerarySection);
        generateItinerary();
    }
}

// Delete trip
function deleteTrip(id) {
    savedTrips = savedTrips.filter(t => t.id !== id);
    localStorage.setItem('savedTrips', JSON.stringify(savedTrips));
    displaySavedTrips();
}

// Theme toggle
themeToggle.addEventListener('click', () => {
    document.body.classList.toggle('dark');
    const icon = themeToggle.querySelector('i');
    if (document.body.classList.contains('dark')) {
        icon.className = 'fas fa-sun';
    } else {
        icon.className = 'fas fa-moon';
    }
});

// Function to update locations based on destination
function updateLocations() {
    const destination = destinationInput.value.toLowerCase().trim();
    const locations = destinationLocations[destination] || [];

    locationsSelect.innerHTML = '<option value="">Select locations after choosing destination</option>';

    if (locations.length > 0) {
        locations.forEach(location => {
            const option = document.createElement('option');
            option.value = location;
            option.textContent = location;
            locationsSelect.appendChild(option);
        });
    }
}

// Function to convert USD to INR
function convertToINR(usd) {
    return Math.round(usd * USD_TO_INR);
}

// Function to calculate budget per person based on budget range and days
function calculateBudgetPerPerson(budgetRange, days) {
    let baseCostPerDay;

    switch (budgetRange) {
        case 'low':
            baseCostPerDay = 1200; // ₹1,200 per day for low budget (₹2000-₹5000 range)
            break;
        case 'medium':
            baseCostPerDay = 3000; // ₹3,000 per day for medium budget (₹10000-₹15000 range)
            break;
        case 'high':
            baseCostPerDay = 6000; // ₹6,000 per day for high budget (₹20000-₹30000 range)
            break;
        case 'luxury':
            baseCostPerDay = 12000; // ₹12,000 per day for luxury budget (above ₹50000)
            break;
        default:
            baseCostPerDay = 3000; // Default to medium
    }

    // Calculate total cost including a 10% buffer for miscellaneous expenses
    let totalCost = baseCostPerDay * days * 1.1;

    // Cap the total cost at ₹1400 for low budget to keep per person cost between ₹1000-₹1400
    if (budgetRange === 'low') {
        totalCost = Math.min(totalCost, 1400);
    }

    return Math.round(totalCost);
}

// Function to generate travel packages
function generatePackages() {
    packagesList.innerHTML = '';

    travelPackages.forEach(pkg => {
        const packageCard = document.createElement('div');
        packageCard.className = 'package-card';
        packageCard.innerHTML = `
            <h4>${pkg.name}</h4>
            <p class="package-price">$${pkg.priceUSD} (${convertToINR(pkg.priceUSD)} INR)</p>
            <p class="package-includes"><strong>Includes:</strong> ${pkg.includes}</p>
            <p>${pkg.description}</p>
        `;
        packagesList.appendChild(packageCard);
    });
}

// Event listener for destination select change
destinationInput.addEventListener('change', updateLocations);

// Function to display quick access saved trips at bottom
function displayQuickSavedTrips() {
    quickTripsList.innerHTML = '';
    if (savedTrips.length === 0) {
        quickTripsList.innerHTML = '<p>No saved trips yet.</p>';
        return;
    }

    // Show only last 3 saved trips for quick access
    const recentTrips = savedTrips.slice(-3).reverse();

    recentTrips.forEach(trip => {
        const tripCard = document.createElement('div');
        tripCard.className = 'quick-trip-card';
        tripCard.innerHTML = `
            <div class="quick-trip-info">
                <h4>${trip.name || trip.destination}</h4>
                <p>${trip.startDate} to ${trip.endDate}</p>
                <p>Budget: ${trip.budget} | Type: ${trip.travelType}</p>
            </div>
            <button class="btn primary small" onclick="viewTrip(${trip.id})">View</button>
        `;
        quickTripsList.appendChild(tripCard);
    });
}

// Destinations for carousel
const carouselDestinations = [
    {
        name: 'Delhi',
        image: 'https://imgs.search.brave.com/qBDhq7sRWxKlUUIiJ7-ECItdkeOgPlKLdNUc77SiIM8/rs:fit:860:0:0:0/g:ce/aHR0cHM6Ly9jb250/ZW50LmpkbWFnaWNi/b3guY29tL3YyL2Nv/bXAvZGVsaGkvbDEv/MDExcHh4MTEueHgx/MS4xMTExMTYxMDIy/MzMuaDhsMS9jYXRh/bG9ndWUvbGFsLXF1/aWxhLXJlZC1mb3J0/LWRlbGhpLXRvdXJp/c3QtYXR0cmFjdGlv/bi1tYmFjdm9ram15/LTI1MC5qcGc_dz02/NDAmcT03NQ',
        description: 'Experience the rich history and vibrant culture of India\'s capital city.'
    },
    {
        name: 'Agra',
        image: 'https://images.unsplash.com/photo-1524492412937-b28074a5d7da?w=400&h=300&fit=crop',
        description: 'Home to the iconic Taj Mahal and Mughal architecture.'
    },
    {
        name: 'Andhra Pradesh',
        image: 'https://imgs.search.brave.com/E7GsNiCol7ktP0rusfGD-a7uIpwGYRyutkvDH3ZyEPw/rs:fit:860:0:0:0/g:ce/aHR0cHM6Ly9kMzY4/dWZ1N3hnY3M4Ni5j/bG91ZGZyb250Lm5l/dC8yMDEwOS0xNTcx/NTExMTc1LmpwZw',
        description: 'Rich in temples, beaches, and culinary delights.'
    },
    {
        name: 'Jammu Kashmir',
        image: 'https://images.unsplash.com/photo-1469474968028-56623f02e42e?w=400&h=300&fit=crop',
        description: 'Paradise on earth with stunning landscapes and valleys.'
    },
    {
        name: 'Kerala',
        image: 'https://images.unsplash.com/photo-1602216056096-3b40cc0c9944?w=400&h=300&fit=crop',
        description: 'God\'s own country with backwaters, spices, and Ayurveda.'
    },
    {
        name: 'Goa',
        image: 'https://images.unsplash.com/photo-1512343879784-a960bf40e7f2?w=400&h=300&fit=crop',
        description: 'Paradise beaches, vibrant nightlife, and Portuguese heritage.'
    },
    {
        name: 'Manali',
        image: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400&h=300&fit=crop',
        description: 'A haven for adventure seekers with stunning mountain views and trekking opportunities.'
    }
];

// Initialize carousel
function initializeCarousel() {
    const carousel = document.getElementById('destinations-carousel');
    if (!carousel) return;

    carousel.innerHTML = '';

    carouselDestinations.forEach(dest => {
        const destCard = document.createElement('div');
        destCard.className = 'destination-card';
        destCard.innerHTML = `
            <img src="${dest.image}" alt="${dest.name}" loading="lazy">
            <div class="destination-info">
                <h3>${dest.name}</h3>
                <p>${dest.description}</p>
            </div>
        `;
        carousel.appendChild(destCard);
    });
}

// Initialize map
function initializeMap() {
    // Simple map implementation using OpenStreetMap
    const mapContainer = document.getElementById('map');
    if (!mapContainer) return;

    // Get coordinates for selected locations or destination
    let coords = [];
    if (currentItinerary && currentItinerary.locations && currentItinerary.locations.length > 0) {
        const selectedLocs = currentItinerary.locations.filter(loc => loc !== 'ALL');
        coords = selectedLocs.map(loc => locationCoordinates[loc]).filter(coord => coord);
    }

    if (coords.length === 0 && currentItinerary) {
        const destCoords = destinationCoordinates[currentItinerary.destination.toLowerCase()];
        if (destCoords) coords = [destCoords];
    }

    if (coords.length === 0) return;

    // Create simple map display
    mapContainer.innerHTML = `
        <div class="map-placeholder">
            <h4>Map View</h4>
            <p>Locations: ${coords.length} point(s) marked</p>
            <div class="map-coords">
                ${coords.map((coord, index) => `<div>Point ${index + 1}: ${coord[0]}, ${coord[1]}</div>`).join('')}
            </div>
        </div>
    `;
}

// Initialize app
function initializeApp() {
    generatePackages();
    displaySavedTrips();
    updateLocations();
}

// Event listeners
document.addEventListener('DOMContentLoaded', initializeApp);
