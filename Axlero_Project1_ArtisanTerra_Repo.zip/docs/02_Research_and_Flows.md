# 02_Research & Flows — User Personas & Information Architecture

## 1. User Personas

### Persona 1: Maya Lin — "The Conscious Shopper" (Consumer Role)
- **Age / Occupation**: 28, Architectural Interior Stylist
- **Tech Comfort**: High (iOS power user, shops on mobile 85% of the time)
- **Core Goals**:
  - Discover authentic, small-batch ceramics, linen apparel, and lighting from independent makers in one unified app.
  - Check out across multiple vendors in a single transaction without re-entering card or shipping details.
- **Pain Points / Frustrations**:
  - Multi-vendor apps often look chaotic because every seller uploads clashing banners and fonts.
  - Hidden shipping fees and 6-step checkout forms cause immediate cart abandonment.
- **UX Design Response**:
  - Enforced a warm Alabaster (`#F9F6F0`) and White (`#FFFFFF`) card container system with consistent 12px border radii so all vendor products feel curated.
  - Engineered a unified 3-step checkout flow with transparent itemized shipping and tax rows on the Order Summary card.

---

### Persona 2: Marcus Vance — "The Independent Maker" (Vendor Role)
- **Age / Occupation**: 36, Ceramicist & Founder of *Studio Terra*
- **Tech Comfort**: Moderate (manages his studio from his smartphone between kiln firings)
- **Core Goals**:
  - Track daily revenue, order volume, and growth trends at a glance on mobile.
  - Quickly identify low-stock SKUs and add new products in under 60 seconds.
- **Pain Points / Frustrations**:
  - Desktop-only seller portals are impossible to navigate on a phone screen.
  - Complex analytics charts with low contrast are unreadable in bright workshop lighting.
- **UX Design Response**:
  - Designed a mobile-first Seller Dashboard matching the main brand's warm high-contrast palette (`#1E242B` text on `#FFFFFF` cards, 14.8:1 contrast ratio).
  - Added semantic stock badges (*In Stock* `#2E7D5B` vs. *Low Stock* `#D9822B`) and a persistent floating `+ Add Product` button.

---

## 2. Information Architecture (IA) & Navigation Hierarchy

```text
ArtisanTerra Multi-Vendor App
│
├── 1. CONSUMER STOREFRONT FLOW
│   ├── 1.1 Home & Discovery (Search Bar, Visual Scan, Promo Carousel, Category Pills, Product Grid)
│   ├── 1.2 Category Search & Filter (Ceramics, Linen Apparel, Home Decor, Lighting, Sort by Rating/Price)
│   ├── 1.3 Product Detail Page [PDP] (Gallery, Vendor Badge, Color/Size Variants, Reviews, Add to Cart CTA)
│   └── 1.4 3-Step Streamlined Checkout
│       ├── Step 1: PDP "Add to Cart" Trigger
│       ├── Step 2: Order Summary & Payment Gateway Selector (Card, Digital Wallet, COD)
│       └── Step 3: Order Confirmed Receipt & Tracking ID
│
└── 2. VENDOR DASHBOARD FLOW
    ├── 2.1 KPI Overview Row (Total Revenue, Total Orders, Monthly Growth %)
    ├── 2.2 Sales Analytics Chart (7-Day Revenue vs. Order Volume Bar/Trend Graph)
    ├── 2.3 Inventory Management List (SKU Thumbnail, Stock Status Pill, Quick Edit Action)
    └── 2.4 Add New Product Modal/Screen (Title, Category, Price, Stock Count, Publish CTA)
```
