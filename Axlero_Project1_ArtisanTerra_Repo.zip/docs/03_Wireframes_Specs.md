# 03_Wireframes — Low-Fidelity Structural Specifications (Week 1)

All wireframes in `03_Wireframes` are constructed strictly in **grayscale** (`#E5E5E5` containers, `#A3A3A3` placeholders, `#262626` structural labels) with zero photography to validate visual hierarchy and touch-target ergonomics before applying UI tokens.

## Frame-by-Frame Structural Layout (393x852px Mobile Grid)
1. **WF-01: Consumer Home Wireframe**
   - Top App Bar (56px height): Search input pill + Visual camera search icon + Cart badge + Notification bell.
   - Hero Carousel (160px height): 16px horizontal padding, pagination dots centered at bottom.
   - Category Scroller (88px height): 5 circular 56x56px category nodes with 12px centered text labels.
   - Product Bento Grid: 2-column Auto-Layout grid (16px gap), card height 240px with top-right 32x32px favorite button target.
2. **WF-02: Product Detail Page (PDP) Wireframe**
   - Hero Image Container (380px height) with floating Back and Favorite icon buttons (44x44px minimum touch targets).
   - Vendor Pill badge + Price/Rating row + Swatch selector circles (36x36px) + Size pills (S, M, L) + Sticky bottom full-width `Add to Cart` button (52px height).
3. **WF-03: Order Summary & Payment Checkout Wireframe**
   - Top 3-step progress indicator bar.
   - Itemized Order Summary card (thumbnails, vendor sub-labels, subtotal, shipping, tax, bold total).
   - Payment Gateway radio cards (Credit Card, Digital Wallet, Express Pay) + Sticky `Confirm Order` CTA.
4. **WF-04: Vendor Dashboard Wireframe**
   - 3-column KPI summary cards (Revenue, Orders, Growth).
   - Dual-bar Sales Analytics chart container (200px height).
   - Vertical stack of Inventory SKU rows with status indicators and floating `+ Add Product` action button.
