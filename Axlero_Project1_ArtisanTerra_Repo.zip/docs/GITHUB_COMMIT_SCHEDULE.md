# Mandatory GitHub & Figma Version History Compliance Guide

Per the **Axlero Project Execution Handbook V1.1** and the **UI/UX PRD**, interns are audited on both **Figma Version History checkpoints** and **GitHub commit frequency**:
- **Mid Review Rule (23rd–30th of Month)**: Minimum of **10 different commit days** in the 14 days prior to the Mid Review (covering Week 1 + Week 2).
- **Final Review Rule (5th–15th of Next Month)**: Minimum of **20 consecutive commit days (zero gaps allowed)** prior to the Final Review (covering Week 3 + Week 4).

## Daily Git Commands for Your Repository
```bash
# 1. Initialize and push initial repository
git init
git add .
git commit -m "[Week 1] Initial project structure, README, and Work Distribution doc"
git branch -M main
git remote add origin https://github.com/<your-username>/<your-repo-name>.git
git push -u origin main
```

## 20-Day Unbroken Commit Checklist (Copy-Paste Commit Messages)
- **Day 1**: `git commit -m "[Week 1] Add Consumer Shopper persona and empathy map in docs/02_Research_and_Flows.md"`
- **Day 2**: `git commit -m "[Week 1] Add Vendor Maker persona and pain points in docs/02_Research_and_Flows.md"`
- **Day 3**: `git commit -m "[Week 1] Complete Information Architecture tree for Consumer and Seller flows"`
- **Day 4**: `git commit -m "[Week 1] Add grayscale wireframe specs for Consumer Home and Category Search"`
- **Day 5**: `git commit -m "[Week 1] Add grayscale wireframe specs for PDP, 3-step Checkout, and Seller Dashboard"`
- **Day 6**: `git commit -m "[Week 2] Define primary, secondary, and semantic color tokens in design_tokens.json"`
- **Day 7**: `git commit -m "[Week 2] Add typography scale and 8pt spacing tokens to design_tokens.json"`
- **Day 8**: `git commit -m "[Week 2] Export CSS custom properties in tokens/variables.css"`
- **Day 9**: `git commit -m "[Week 2] Document Auto-Layout Button, Input, and Product Card variants"`
- **Day 10 (Mid Review Ready)**: `git commit -m "[Week 2] Link Figma [Week 2] Design System checkpoint in README.md"`
- **Day 11**: `git commit -m "[Week 3] Export navigation SVG icons (home, search, heart, cart) to assets/icons"`
- **Day 12**: `git commit -m "[Week 3] Export vendor SVG icons (store, analytics, plus) to assets/icons"`
- **Day 13**: `git commit -m "[Week 3] Build Consumer Home and Category filter UI in index.html"`
- **Day 14**: `git commit -m "[Week 3] Build Product Detail Page (PDP) with variant selectors in index.html"`
- **Day 15**: `git commit -m "[Week 3] Build 3-step Order Summary and Payment Gateway UI in index.html"`
- **Day 16**: `git commit -m "[Week 3] Build Seller Dashboard with KPI cards and Sales Analytics chart"`
- **Day 17**: `git commit -m "[Week 3] Add Vendor Inventory Management table and Add Product modal"`
- **Day 18**: `git commit -m "[Week 4] Add Smart Animate heart micro-interaction and interactive cart drawer"`
- **Day 19**: `git commit -m "[Week 4] Add 8pt grid redline overlay and WCAG 2.1 AA contrast audit table"`
- **Day 20 (Final Review Ready)**: `git commit -m "[Week 4] Finalize all 7 Figma pages in index.html and HM presentation script"`
