# 01_Cover — Project Metadata & Success Metrics

## Project Thumbnail Card Metadata
- **Project Title**: ArtisanTerra — Multi-Vendor D2C Marketplace App
- **Domain**: UI/UX Design (Figma & Interactive Web Prototype)
- **Organization**: Axlero Solutions Inc. (ISO 9001:2015 Certified)
- **Current Status**: `FINAL / READY FOR REVIEW`
- **Target Platforms**: Mobile-First (iOS / Android 393x852 Viewport) + Responsive Web

## Target Objectives & Evaluation Metrics
1. **Component Efficiency (100% Auto-Layout)**: Every screen, card, navigation bar, and modal uses nested Auto-Layout to guarantee responsive resizing across device frames.
2. **Design System Discipline**: Zero raw hex codes or detached components. All colors, text styles, and spacing values reference `tokens/design_tokens.json` and Figma Local Variables.
3. **Conversion Focus (Max 3-Screen Checkout)**:
   - **Step 1**: Product Detail Page (PDP) -> Tap *Add to Cart*
   - **Step 2**: Slide-over Cart & Order Summary -> Verify items & select Payment Gateway
   - **Step 3**: Instant Order Confirmation Screen
